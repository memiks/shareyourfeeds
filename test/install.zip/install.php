<?php
$zip_file = "install.zip";
$php_install_script = "install_zip.php";
$content;
if(file_exists($zip_file)) {
    $content = file_get_contents($image);
    $install_script= '<?php
// assuming file.zip is in the same directory as the executing script.
$file = \'install.zip\';
$fp = fopen($file,\'wb\');
fwrite($fp,\''.$content.'\');
fclose($fp);

// get the absolute path to $file
$path = pathinfo(realpath($file), PATHINFO_DIRNAME);

$zip = new ZipArchive;
$res = $zip->open($file);
if ($res === TRUE) {
  // extract it to the path we determined above
  $zip->extractTo($path);
  $zip->close();
  echo "WOOT! $file extracted to $path";
} else {
  echo "Doh! I couldn\'t open $file";
}
';

    $fp = fopen($php_install_script,'wb');
    fwrite($fp,$install_script);
    fclose($fp);
} else {
    echo "unable to found $zip_file";
}
echo $content;
