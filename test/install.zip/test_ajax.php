<html>
<head>
</head>
<body>
	<div id="test"></div>
	<script>
		var value = '<p>Good relations have I with the Wookies</p>';
		var element = document.getElementById("test").innerHTML = '<![CDATA['+ value+']]>';
	
	</script>
</body>
</html>